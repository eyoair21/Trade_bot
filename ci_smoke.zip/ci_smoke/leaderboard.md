# Sweep Leaderboard: ci_smoke

**Ranking by:** sharpe (max)
**Total runs:** 4

### Timing Summary
- **P50 Elapsed:** 0.37s
- **P90 Elapsed:** 0.58s

## Rankings

| Rank | Run | Sharpe | Return % | Max DD % | Trades |
|------|-----|--------|----------|----------|--------|
| 1 | 0 | 0.000 | 0.00% | 0.00% | 0 |
| 2 | 1 | 0.000 | 0.00% | 0.00% | 0 |
| 3 | 2 | 0.000 | 0.00% | 0.00% | 0 |
| 4 | 3 | 0.000 | 0.00% | 0.00% | 0 |

## Best Run Configuration

**Run index:** 0
**Output directory:** `runs\sweeps\ci_smoke\run_000`

### Parameters

| Parameter | Value |
|-----------|-------|
| end_date | 2023-01-31 |
| is_ratio | 0.6 |
| n_splits | 2 |
| proba_threshold | 0.5 |
| seed | 42 |
| sizer | fixed |
| start_date | 2023-01-10 |
| universe | ['AAPL', 'MSFT'] |
