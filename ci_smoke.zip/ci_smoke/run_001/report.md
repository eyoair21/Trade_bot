# Walk-Forward Analysis Report

## Run Manifest

| Parameter | Value |
|-----------|-------|
| Run ID | `run_001` |
| Git SHA | `15684e4e` |
| Seed | `43` |
| Start Date | 2023-01-10 |
| End Date | 2023-01-31 |
| Universe | AAPL, MSFT |
| Splits | 2 |
| IS Ratio | 0.6 |
| Sizer | fixed |
| Sizer Params | fixed_frac=0.1, vol_target=0.2, kelly_cap=0.25 |
| Data Digest | `1e492fc130c6f26b` |

## Summary Metrics

| Metric | Value |
|--------|-------|
| Avg OOS Return | 0.00% |
| Avg OOS Sharpe | 0.000 |
| Avg OOS Max DD | 0.00% |
| Total OOS Trades | 0 |

## Execution Costs

| Cost Type | Amount |
|-----------|--------|
| Commission | $0.00 |
| Per-Share Fees | $0.00 |
| Slippage | $0.00 |
| **Total** | **$0.00** |

## Split Details

| Split | IS Period | OOS Period | IS Return | OOS Return | IS Sharpe | OOS Sharpe | OOS Trades |
|-------|-----------|------------|-----------|------------|-----------|------------|------------|
| 1 | 2023-01-10 to 2023-01-13 | 2023-01-16 to 2023-01-19 | 0.00% | 0.00% | 0.000 | 0.000 | 0 |
| 2 | 2023-01-20 to 2023-01-25 | 2023-01-26 to 2023-01-31 | 0.00% | 0.00% | 0.000 | 0.000 | 0 |

## Probability Thresholds

| Split | Threshold |
|-------|-----------|
| 1 | 0.550 |
| 2 | 0.550 |
